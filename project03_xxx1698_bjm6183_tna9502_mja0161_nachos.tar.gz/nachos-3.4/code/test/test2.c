
#include "syscall.h"

int main() {
	
	int i = 0;
	int j = 0;
	char * Msg ="HAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHHAAHAHAHHHAH";
	
   for (i=0;i<50;i++)
	{
		j++;
	}

	Yield();
//	Exit(1);
}
