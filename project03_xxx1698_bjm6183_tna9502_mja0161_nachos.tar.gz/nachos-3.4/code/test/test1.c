

int main() {
	int i = 0;
	int j = 0;


    for (i=0;i<15;i++)
	{
		j++;
	}

	Exit(0);
} 
